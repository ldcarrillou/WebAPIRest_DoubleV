﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIRest_DoubleV.Models
{
    public class Ticket
    {
        public int Id { get; set; }
        public string Usuario { get; set; }
        public DateTime? Fecha_creacion { get; set; }
        public DateTime? Fecha_actualizacion { get; set; }
        public string Estatus { get; set; }
    }
}
