﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebAPIRest_DoubleV.Models;

namespace WebAPIRest_DoubleV.Data
{
    public class WebAPIRest_DoubleVContext : DbContext
    {
        public WebAPIRest_DoubleVContext (DbContextOptions<WebAPIRest_DoubleVContext> options)
            : base(options)
        {
        }

        public DbSet<WebAPIRest_DoubleV.Models.Ticket> Ticket { get; set; }
    }
}
